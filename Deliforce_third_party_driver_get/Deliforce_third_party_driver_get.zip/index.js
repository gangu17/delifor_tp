let cb;
const result = require('./result');

try {

  const getConstant = require('./constant')();
  // const callback = function (err, data) {
  //   console.log('callback called+++++++++++++++++++++++++++++++++');
  //   console.log(err, data);
  // };
  // const event = {
  //     "resource": "/driver",
  //     "path": "/driver",
  //     "httpMethod": "GET",
  //     "headers": {
  //         "Accept": "*/*",
  //         "Accept-Encoding": "deflate, gzip",
  //         "apiKey": "bFbFbbFbFbYGNFTSwlegKwDaFaFa2ToNtNzVCQMfLxHCt5aFaFamcH9iqoWUxZ1aFaFaESezx6mVgaZS7AcFcFc",
  //         "cache-control": "no-cache",
  //         "CloudFront-Forwarded-Proto": "https",
  //         "CloudFront-Is-Desktop-Viewer": "true",
  //         "CloudFront-Is-Mobile-Viewer": "false",
  //         "CloudFront-Is-SmartTV-Viewer": "false",
  //         "CloudFront-Is-Tablet-Viewer": "false",
  //         "CloudFront-Viewer-Country": "IN",
  //         "Content-Type": "application/x-www-form-urlencoded",
  //         "Host": "b3avswn5h0.execute-api.ap-south-1.amazonaws.com",
  //         "Postman-Token": "5d44d5e2-e368-41c3-9f67-0cbcd523eb22",
  //         "Via": "1.1 60276c945ec58972cc6306cf00aab714.cloudfront.net (CloudFront)",
  //         "X-Amz-Cf-Id": "mond4ORMozGsjhEh1yxaCs5EFyXrAVaW_wwxrRXZd8GxacMSR0LYAQ==",
  //         "X-Amzn-Trace-Id": "Root=1-5c402d76-c399b68aeb46ce958b0b8992",
  //         "X-Forwarded-For": "106.51.73.130, 52.46.49.76",
  //         "X-Forwarded-Port": "443",
  //         "X-Forwarded-Proto": "https"
  //     },
  //     "multiValueHeaders": {
  //         "Accept": [
  //             "*/*"
  //         ],
  //         "Accept-Encoding": [
  //             "deflate, gzip"
  //         ],
  //         "apiKey": [
  //             "bFbFbbFbFbYGNFTSwlegKwDaFaFa2ToNtNzVCQMfLxHCt5aFaFamcH9iqoWUxZ1aFaFaESezx6mVgaZS7AcFcFc"
  //         ],
  //         "cache-control": [
  //             "no-cache"
  //         ],
  //         "CloudFront-Forwarded-Proto": [
  //             "https"
  //         ],
  //         "CloudFront-Is-Desktop-Viewer": [
  //             "true"
  //         ],
  //         "CloudFront-Is-Mobile-Viewer": [
  //             "false"
  //         ],
  //         "CloudFront-Is-SmartTV-Viewer": [
  //             "false"
  //         ],
  //         "CloudFront-Is-Tablet-Viewer": [
  //             "false"
  //         ],
  //         "CloudFront-Viewer-Country": [
  //             "IN"
  //         ],
  //         "Content-Type": [
  //             "application/x-www-form-urlencoded"
  //         ],
  //         "Host": [
  //             "b3avswn5h0.execute-api.ap-south-1.amazonaws.com"
  //         ],
  //         "Postman-Token": [
  //             "5d44d5e2-e368-41c3-9f67-0cbcd523eb22"
  //         ],
  //         "Via": [
  //             "1.1 60276c945ec58972cc6306cf00aab714.cloudfront.net (CloudFront)"
  //         ],
  //         "X-Amz-Cf-Id": [
  //             "mond4ORMozGsjhEh1yxaCs5EFyXrAVaW_wwxrRXZd8GxacMSR0LYAQ=="
  //         ],
  //         "X-Amzn-Trace-Id": [
  //             "Root=1-5c402d76-c399b68aeb46ce958b0b8992"
  //         ],
  //         "X-Forwarded-For": [
  //             "106.51.73.130, 52.46.49.76"
  //         ],
  //         "X-Forwarded-Port": [
  //             "443"
  //         ],
  //         "X-Forwarded-Proto": [
  //             "https"
  //         ]
  //     },
  //     "queryStringParameters": {
  //         "distance": "77.6974",
  //         "limit": "10",
  //         "page": "1"
  //     },
  //     "multiValueQueryStringParameters": {
  //         "distance": [
  //             "12.9592",
  //             "77.6974"
  //         ],
  //         "limit": [
  //             "10"
  //         ],
  //         "page": [
  //             "1"
  //         ]
  //     },
  //     "pathParameters": null,
  //     "stageVariables": null,
  //     "requestContext": {
  //         "resourceId": "q41ihn",
  //         "authorizer": {
  //             "principalId": "{\"sub\":\"e08cac38-e213-4474-87c6-00764539d649\",\"role\":1}"
  //         },
  //         "resourcePath": "/driver",
  //         "httpMethod": "GET",
  //         "extendedRequestId": "TowKdFF3hcwFjMA=",
  //         "requestTime": "17/Jan/2019:07:23:34 +0000",
  //         "path": "/Development/driver",
  //         "accountId": "786724127547",
  //         "protocol": "HTTP/1.1",
  //         "stage": "Development",
  //         "domainPrefix": "b3avswn5h0",
  //         "requestTimeEpoch": 1547709814110,
  //         "requestId": "cc5be859-1a28-11e9-b838-d171d7494e0e",
  //         "identity": {
  //             "cognitoIdentityPoolId": null,
  //             "accountId": null,
  //             "cognitoIdentityId": null,
  //             "caller": null,
  //             "sourceIp": "106.51.73.130",
  //             "accessKey": null,
  //             "cognitoAuthenticationType": null,
  //             "cognitoAuthenticationProvider": null,
  //             "userArn": null,
  //             "userAgent": null,
  //             "user": null
  //         },
  //         "domainName": "b3avswn5h0.execute-api.ap-south-1.amazonaws.com",
  //         "apiId": "b3avswn5h0"
  //     },
  //     "body": null,
  //     "isBase64Encoded": false
  // }
 //event.queryStringParameters = data.driverFetch;
  exports.handler = (event, context, callback) => {
    console.log('Event', JSON.stringify(event));
    cb = callback;
   context.callbackWaitsForEmptyEventLoop = false;

    getConstant.then(() => {
      //imports
      const db = require('./db').connect();
      const driver = require('./driver');
      const helper = require('./util');

      if (helper.checkFromTrigger(cb, event)) return;

      /*
      principals explanation: for admin sub is clientId for manager clientId is clientId
      {  sub: 'current user cognitosub',
      role: 'role id of user',
      clientId:'exist if user is manager & this is clientid of that manager',
      teams: 'team Assigned to manager' }
      */

      const principals = helper.getPrincipals(cb, event);
      if (!principals) return;
      console.log(JSON.stringify(principals));


      //connect to db
      db.then(() => driver.getDrivers(event, cb, principals)).catch(sendError);

      function sendError(error) {
        console.error('error +++', error);
        result.sendServerError(cb);
      }
    }).catch((err) => {
      console.log(err);
      result.sendServerError(cb);
    });
 };
} catch (err) {
  console.error('error +++', err);
  result.sendServerError(cb);
}


