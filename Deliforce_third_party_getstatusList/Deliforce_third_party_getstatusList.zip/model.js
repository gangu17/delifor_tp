var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var driverSettingSchema = new Schema({

});

module.exports = mongoose.model('users', driverSettingSchema);
