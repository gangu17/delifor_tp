const result = require('./result');
const helper = require('./util');
const constant = require('./constant')();
const isIt = constant.isIt;
const webhookModel = require('./model');
const securePin = require("secure-pin");

module.exports = {
    create: (event, cb, principals) => {
        const clientId = (helper.isAdmin(principals)) ? principals['sub'] : principals['clientId'];
        const data = helper.getBodyData(event);
        // const data = {
        //     name: "hello",
        //     trigger: 4,
        //     url: "https://www.app.deliforce.io"
        // };
        //   data.clientId = "9846184651asd486a5sda4sd5ad45";
        if (!data) {
            result.invalidInput(cb);
        }
        data.clientId = clientId;
        var urlExists = require('promised-url-exists');
        urlExists(data.url).then((res) => {
            console.log(JSON.stringify(res) + 'line 24') ;
            if(res.exists === false) {
                result.sendUrlNotExixts(cb);
            } else {
                webhookModel.find({
                    clientId: clientId,
                    trigger: data.trigger,
                    isDeleted: isIt.NO
                }).then((resultData) => {
                    if (resultData.length) {
                        console.log(JSON.stringify(resultData));
                        result.duplicateTrigger(cb);
                    } else {
                        upsertTrigger(data, clientId, cb);
                    }
                })
            }
        }).catch((err) => {
            console.log(err);
            result.sendServerError(cb);
        })
    }
};

function upsertTrigger(data, clientId, cb) {
    console.log('38'+JSON.stringify(data) );
    let promise;
    data.name = data.webhookName;
    data.webhookId = securePin.generatePinSync(8);
    const newTrigger = new webhookModel(data);
    promise = newTrigger.save();
    promise.then((data) => {
        result.sendSuccess(cb, data);
    }).catch((error) => {
        console.log(error + 'line 44');
        result.sendServerError(cb);
    });
}

